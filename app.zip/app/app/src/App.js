import React, { useEffect, useState } from 'react';
import KanbanDashboard from './KanbanDashboard';

function App() {


  return (
    <div>
        <KanbanDashboard />
    </div>
  );
}

export default App;

